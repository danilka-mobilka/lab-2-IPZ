package ua.edu.krnu.javatech.web;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.util.Map;

public class HelloHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            HttpUtil.sendError(exchange, 405, "Method Not Allowed");
            return;
        }

        Map<String, String> params =
                HttpUtil.parseQuery(exchange.getRequestURI().getQuery());
        String name = params.get("name");

        if (name == null || name.isEmpty()) {
            HttpUtil.sendError(exchange, 400,
                    "Query parameter 'name' is required.");
            return;
        }

        String html = """
                <!DOCTYPE html>
                <html><head><meta charset="UTF-8">
                <title>Hello</title></head><body>
                <h1>Hello, %s!</h1>
                <p>HTTP method: %s</p>
                <p>Request URI: %s</p>
                <p>Query string: %s</p>
                <p><a href="/">Home</a></p>
                </body></html>
                """.formatted(
                HttpUtil.escapeHtml(name),
                HttpUtil.escapeHtml(exchange.getRequestMethod()),
                HttpUtil.escapeHtml(exchange.getRequestURI().toString()),
                HttpUtil.escapeHtml(String.valueOf(exchange.getRequestURI().getQuery()))
        );

        HttpUtil.sendHtml(exchange, 200, html);
    }
}