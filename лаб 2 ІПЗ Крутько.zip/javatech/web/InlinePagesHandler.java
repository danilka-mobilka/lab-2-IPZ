package ua.edu.krnu.javatech.web;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;

public class InlinePagesHandler implements HttpHandler {

    private static final String INDEX = """
            <!DOCTYPE html>
            <html><head><meta charset="UTF-8">
            <title>Java Technologies Lab 02</title></head><body>
            <h1>Java Technologies Lab 02 — BatteryPack</h1>
            <ul>
                <li><a href="/hello?name=Student">Hello Handler</a></li>
                <li><a href="/batteries">Battery list</a></li>
                <li><a href="/battery-form.html">Add battery</a></li>
            </ul>
            </body></html>
            """;

    private static final String FORM = """
            <!DOCTYPE html>
            <html lang="en"><head><meta charset="UTF-8">
            <title>Add battery pack</title></head><body>
            <h1>Add battery pack</h1>
            <form action="/batteries" method="post">
                <p><label>Serial number:
                    <input type="text" name="serialNumber" required></label></p>
                <p><label>Chemistry:
                    <input type="text" name="chemistry" required></label></p>
                <p><label>Nominal voltage (V):
                    <input type="number" step="0.1" name="nominalVoltage" required></label></p>
                <p><label>Capacity (Ah):
                    <input type="number" step="0.1" name="capacityAh" required></label></p>
                <p><label>Charge percent:
                    <input type="number" min="0" max="100" name="chargePercent" required></label></p>
                <p><label>Location:
                    <input type="text" name="location" required></label></p>
                <p><label>Status:
                    <select name="status">
                        <option value="NORMAL">NORMAL</option>
                        <option value="LOW_CHARGE">LOW_CHARGE</option>
                        <option value="CHARGING">CHARGING</option>
                        <option value="FAULT">FAULT</option>
                        <option value="MAINTENANCE">MAINTENANCE</option>
                    </select></label></p>
                <button type="submit">Add battery</button>
            </form>
            <p><a href="/batteries">Back to list</a></p>
            </body></html>
            """;

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath();
        if (path.equals("/") || path.equals("/index.html")) {
            HttpUtil.sendHtml(exchange, 200, INDEX);
        } else if (path.equals("/battery-form.html")) {
            HttpUtil.sendHtml(exchange, 200, FORM);
        } else {
            HttpUtil.sendError(exchange, 404, "Not Found: " + path);
        }
    }
}