package ua.edu.krnu.javatech.web;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;

public class BatteryPackHandler implements HttpHandler {

    public BatteryPackHandler() {
        System.out.println("BatteryPackHandler initialized.");
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        HttpUtil.sendHtml(exchange, 200,
                "<html><body><h1>BatteryPackHandler works</h1></body></html>");
    }
}