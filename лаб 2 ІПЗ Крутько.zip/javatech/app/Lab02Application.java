package ua.edu.krnu.javatech.app;

import com.sun.net.httpserver.HttpServer;
import ua.edu.krnu.javatech.web.BatteryPackHandler;
import ua.edu.krnu.javatech.web.HelloHandler;
import ua.edu.krnu.javatech.web.InlinePagesHandler;

import java.net.InetSocketAddress;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.Executors;

public class Lab02Application {

    public static void main(String[] args) throws Exception {
        int port = 8080;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        server.createContext("/hello", new HelloHandler());
        server.createContext("/batteries", new BatteryPackHandler());

        Path webapp = Paths.get("webapp").toAbsolutePath();
        server.createContext("/", new InlinePagesHandler());


        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        server.start();

        System.out.println("Server started at http://localhost:" + port + "/");
        System.out.println("Static root: " + webapp);
    }
}